// AuthForm component archived: moved original to frontend/archive/AuthForm.jsx
// The component is kept as a harmless stub to avoid import errors if something
// references it. It renders nothing.
import React from 'react';

export default function AuthForm() {
  return null;
}