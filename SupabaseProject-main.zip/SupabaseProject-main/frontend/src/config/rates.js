// Rates loader archived: original content moved to frontend/archive/rates.js
// This slim stub returns an empty object to keep any imports safe.

export async function getRates() {
  console.warn('getRates() called from archived rates stub - returning empty object.');
  return {};
}
